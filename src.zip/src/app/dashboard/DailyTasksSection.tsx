"use client";

import React from "react";
import { Goal } from "./interfaces";
import GoalTasks from "./GoalTasks";

interface DailyTasksSectionProps {
  goals: Goal[];
  onComplete: (goalId: number) => void;
}

const DailyTasksSection: React.FC<DailyTasksSectionProps> = ({ goals, onComplete }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6 w-full text-center">
      <h2 className="text-lg font-semibold border-b border-gray-600 pb-2">
        📌 Dnešní úkoly
      </h2>
      <div className="mt-4">
        {goals.map((goal) => (
          <GoalTasks
            key={goal.id}
            goal={goal}
            onComplete={onComplete}
          />
        ))}
      </div>
      <button className="mt-6 px-6 py-3 bg-purple-500 text-white rounded-lg hover:scale-105 transition-transform">
        ✅ Dokončit úkoly
      </button>
    </div>
  );
};

export default DailyTasksSection; 