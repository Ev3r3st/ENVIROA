"use client";

import React, { useEffect, useState, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Cookies from "js-cookie";

// Import typů a rozhraní
import { Goal, Progress, UserCourse } from "./interfaces";

// Import komponent
import MotivationalModal from "./MotivationalModal";
import GoalProgress from "./GoalProgress";
import GoalList from "./GoalList";
import DailyTasksSection from "./DailyTasksSection";
import GoalReminder from "./GoalReminder";
import CourseSection from "./CourseSection";
import MotivationStats from "./MotivationStats";
import Header from "./Header";

// ========== Hlavní komponenta DashboardPage ==========

const DashboardPage: React.FC = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [userCourses, setUserCourses] = useState<UserCourse[]>([]);
  const [activeCourse, setActiveCourse] = useState<UserCourse | null>(null);
  const [loading, setLoading] = useState(true);

  // State pro modální okno s motivací
  const [showMotivationModal, setShowMotivationModal] = useState(false);
  const [motivationalQuote, setMotivationalQuote] = useState("");
  const [currentEmoji, setCurrentEmoji] = useState("✨");

  // Motivační citáty
  const motivationalQuotes = [
    "Každý krok, který děláš, tě přibližuje k tvému cíli. Jsem na tebe hrdý!",
    "Tvoje vytrvalost je obdivuhodná. Pokračuj dál, dokážeš to!",
    "I malý pokrok každý den vede k velkým výsledkům. Skvělá práce!",
    "Tvoje odhodlání je inspirací. Nevzdávej se, jsi na správné cestě!",
    "To, že jsi dnes tady, ukazuje, jak silnou vůli máš. Gratuluji!",
    "Překážky jsou jen výzvou pro tvou sílu. Jsi skvělý, že pokračuješ!",
    "Úspěch není cíl, ale cesta. A ty jdeš tou cestou skvěle!",
    "Sebedisciplína je tvůj klíč k úspěchu. A ty ji máš!",
  ];

  // Motivační emoji
  const motivationalEmojis = [
    "✨",
    "🌟",
    "💪",
    "🚀",
    "🏆",
    "🔥",
    "💯",
    "⭐",
    "🌈",
    "🌻",
  ];

  // State pro sledování aktuálně vybraného cíle
  const [activeGoalIndex, setActiveGoalIndex] = useState(0);

  // useEffect pro zobrazení motivačního okna 3× denně
  useEffect(() => {
    // Funkce pro kontrolu, zda se má zobrazit motivační modální okno
    const checkMotivationModal = () => {
      const today = new Date().toDateString();
      const motivationData = localStorage.getItem("motivationModalData");
      let count = 0;
      let lastDate = "";

      if (motivationData) {
        const data = JSON.parse(motivationData);
        lastDate = data.date;
        count = data.count;
      }

      // Pokud je nový den nebo jsme ještě nedosáhli 3 zobrazení za den
      if (lastDate !== today || count < 3) {
        // Resetovat počítadlo, pokud je nový den
        if (lastDate !== today) {
          count = 0;
        }

        // Vyber náhodný motivační citát
        const randomIndex = Math.floor(
          Math.random() * motivationalQuotes.length
        );
        setMotivationalQuote(motivationalQuotes[randomIndex]);

        // Vyber náhodné emoji
        const randomEmojiIndex = Math.floor(
          Math.random() * motivationalEmojis.length
        );
        setCurrentEmoji(motivationalEmojis[randomEmojiIndex]);

        // Zobraz modální okno
        setShowMotivationModal(true);

        // Aktualizuj počítadlo a ulož informace
        localStorage.setItem(
          "motivationModalData",
          JSON.stringify({
            date: today,
            count: count + 1,
          })
        );
      }
    };

    // Kontroluj modální okno až po načtení dat
    if (!loading) {
      checkMotivationModal();
    }
  }, [loading, motivationalQuotes, motivationalEmojis]);

  // Funkce pro zavření modálního okna
  const closeMotivationModal = () => {
    setShowMotivationModal(false);
  };

  // Funkce pro přepínání mezi cíli
  const navigateToNextGoal = () => {
    if (goals.length > 0) {
      setActiveGoalIndex((prevIndex) =>
        prevIndex === goals.length - 1 ? 0 : prevIndex + 1
      );
    }
  };

  const navigateToPreviousGoal = () => {
    if (goals.length > 0) {
      setActiveGoalIndex((prevIndex) =>
        prevIndex === 0 ? goals.length - 1 : prevIndex - 1
      );
    }
  };

  // 1) Načítáme seznam cílů a progress z DB
  useEffect(() => {
    const fetchAllData = async () => {
      const token = Cookies.get("token");
      if (!token) {
        router.replace("/login");
        return;
      }

      try {
        // Zavoláme /api/goals, /api/progress a /api/courses/user/:userId
        const [resGoals, resProgress, resUserCourses] = await Promise.all([
          fetch("http://localhost:3001/api/goals", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }),
          fetch("http://localhost:3001/api/goals/progress", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }),
          fetch("http://localhost:3001/api/courses/my/courses", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }),
        ]);

        if (!resGoals.ok || !resProgress.ok || !resUserCourses.ok) {
          throw new Error("Failed to fetch data");
        }

        const [goalsData, progressData, userCoursesData] = await Promise.all([
          resGoals.json(),
          resProgress.json(),
          resUserCourses.json(),
        ]);

        setGoals(goalsData);
        setProgress(progressData);
        setUserCourses(userCoursesData);

        // Pokud máme kurzy, nastavíme první aktivní jako aktivní
        if (userCoursesData.length > 0) {
          const activeCourses = userCoursesData.filter(
            (course: UserCourse) => !course.completedAt
          );

          if (activeCourses.length > 0) {
            // Zkontrolovat URL parametr courseId
            const courseIdParam = searchParams?.get("courseId");

            if (courseIdParam) {
              // Najít kurz podle ID v URL
              const courseById = activeCourses.find(
                (c: UserCourse) => c.course.id === parseInt(courseIdParam)
              );

              if (courseById) {
                setActiveCourse(courseById);
              } else {
                setActiveCourse(activeCourses[0]);
              }
            } else {
              // Jinak nastavit první aktivní kurz
              setActiveCourse(activeCourses[0]);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAllData();
  }, [router, searchParams]);

  // 2) Callback, když se uživatel dokončí denní úkoly pro 1 cíl
  const handleDailyTasksComplete = useCallback(async (goalId: number) => {
    try {
      const token = Cookies.get("token");
      if (!token) return;

      // Zavoláme POST /api/progress/:goalId/complete
      const res = await fetch(
        `http://localhost:3001/api/goals/progress/${goalId}/complete`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (!res.ok) {
        throw new Error("Failed to complete daily tasks");
      }
      // Vrátí aktualizovaný záznam progressu
      const updatedProgress: Progress = await res.json();

      // Pokud progress pro goalId neexistoval, přidáme nový.
      // Pokud existoval, aktualizujeme.
      setProgress((prev) => {
        const index = prev.findIndex((p) => p.goalId === goalId);
        if (index === -1) {
          return [...prev, updatedProgress];
        }
        const newProgressArray = [...prev];
        newProgressArray[index] = updatedProgress;
        return newProgressArray;
      });
    } catch (error) {
      console.error("Error completing daily tasks:", error);
    }
  }, []);

  // 3) Výpočet celkového duration
  const totalDuration = goals.reduce((sum, g) => sum + g.duration, 0);

  // 4) Celkem splněných dnů (completedDays) z progressu
  const totalCompletedDays = progress.reduce(
    (sum, p) => sum + p.completedDays,
    0
  );

  // 5) Celkové % (celkem splněných dnů / součet duration) * 100
  const overallProgress =
    totalDuration > 0 ? (totalCompletedDays / totalDuration) * 100 : 0;

  // 6) Day Streaks = max(p.streak) z progressu
  const dayStreak =
    progress.length > 0 ? Math.max(...progress.map((p) => p.completedDays)) : 0;

  // ====== Render UI ======
  if (loading) {
    return <div>Loading...</div>;
  }

  if (goals.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl text-center w-full max-w-md">
          <h2 className="text-3xl font-semibold text-gray-900 dark:text-white mb-4">
            Nemáte žádné cíle
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Vytvořte si svůj první cíl a začněte svou cestu k úspěchu.
          </p>
          <button
            onClick={() => router.push("/GoalFormPage")}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-700 text-white font-medium rounded-lg shadow-md hover:scale-105 transition-transform duration-200"
          >
            Vytvořit cíl
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Pozadí */}
      <div className="fixed inset-0 w-full h-full -z-10">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: "url('/images/app-image/background.png')",
            opacity: 1,
          }}
        />
        <div className="absolute inset-0 bg-black/50" />
      </div>

      <div className="flex flex-col items-center min-h-screen text-white font-sans mb-20 md:mt-20 pt-16">
        {/* Modální okno s motivací */}
        <MotivationalModal
          isOpen={showMotivationModal}
          onClose={closeMotivationModal}
          quote={motivationalQuote}
          emoji={currentEmoji}
        />

        <div className="w-full max-w-4xl mx-auto p-2">
          {/* Header s logem a profilem */}
          <Header />

          {/* Wrapper s kartami */}
          <div className="flex flex-col items-center space-y-4 my-4 w-full">
            {/* Goals a Day Streaks */}
            <GoalProgress
              overallProgress={overallProgress}
              dayStreak={dayStreak}
            /> {/* Připomenutí cíle */}
            <GoalReminder
              goals={goals}
              progress={progress}
              activeGoalIndex={activeGoalIndex}
              onPrevious={navigateToPreviousGoal}
              onNext={navigateToNextGoal}
            />
            {/* Dnešní úkoly */}
            <DailyTasksSection
              goals={goals}
              onComplete={handleDailyTasksComplete}
            />
            {/* Seznam cílů */}
            <GoalList goals={goals} />

           

            {/* Sekce kurzů */}
            <CourseSection
              activeCourse={activeCourse}
              userCourses={userCourses}
            />

            {/* Motivace a statistika */}
            <MotivationStats
              totalCompletedDays={totalCompletedDays}
              overallProgress={overallProgress}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default DashboardPage;
